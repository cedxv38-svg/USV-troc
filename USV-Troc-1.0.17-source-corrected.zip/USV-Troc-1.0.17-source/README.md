# USV Troc 1.0.17

Version Android : 1.0.17
Version code : 18
Package : fr.usv.troc

Correctifs principaux :
- correction du bouton « Contacter le membre » et de la navigation vers la messagerie ;
- fermeture fiable de la fiche produit via la croix et le retour Android ;
- session Supabase persistante après fermeture/réouverture de l'application, avec sauvegarde IndexedDB de secours ;
- messages d'erreur de messagerie plus explicites.

Sécurité : le mot de passe utilisateur n'est pas stocké en clair. La session d'authentification est conservée de façon persistante sur l'appareil.
